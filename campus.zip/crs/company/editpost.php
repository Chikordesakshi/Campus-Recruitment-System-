<?php
session_start();
require_once("../db.php");
//If user clicked register button
if(isset($_POST)) {
	//Escape Special Characters In String First
	$jobtitle = mysqli_real_escape_string($conn, $_POST['jobtitle']);
	$description = mysqli_real_escape_string($conn, $_POST['description']);
	$minimumsalary = mysqli_real_escape_string($conn, $_POST['minimumsalary']);
	$maximumsalary = mysqli_real_escape_string($conn, $_POST['maximumsalary']);
	$stream = mysqli_real_escape_string($conn, $_POST['stream']);
	$jobtype = mysqli_real_escape_string($conn, $_POST['jobtype']);
	$sql = "UPDATE job_post SET jobtitle='$jobtitle', description='$description', minimumsalary='$minimumsalary', maximumsalary='$maximumsalary', stream='$stream', jobtype='$jobtype' WHERE id_jobpost='$_POST[target_id]' AND id_company='$_SESSION[id_user]'";
	if($conn->query($sql)===TRUE) {
		$_SESSION['jobPostUpdateSuccess'] = true;
		header("Location: dashboard.php");
		exit();
	} else {
		echo "Error " . $sql . "<br>" . $conn->error;
	}
	$conn->close();
} else {
	header("Location: dashboard.php");
	exit();
}