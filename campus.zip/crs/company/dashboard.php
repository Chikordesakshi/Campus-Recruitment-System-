<?php
session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: ../index.php");
  exit();
}

require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Dashboard</title>

   
    <link rel="stylesheet" href="../assets/css/templatemo-digimedia-v1.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>

    <!-- NAVIGATION BAR -->    
    <section>
      <div class="container"style=" font-family: Copperplate, Papyrus, fantasy;">
        <div class="row">
        <!-- ***** Header Area Start ***** -->
          <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
            <div class="container">
              <div class="row">
                <div class="col-12">
                  <nav class="main-nav">
                  <!-- ***** Logo Start ***** -->
                    <a href="../homepage_1.php" class="logo">
                      <img src="../assets/images/C1.jpg" alt=" LOGO">
                    </a>
                  <!-- ***** Logo End ***** -->
                    <ul class="nav">
                      <li class="scroll-to-section"><a href="../homepage_1.php">Home</a></li>
                      <li class="scroll-to-section"><a href="view-job-application.php">view Application</a></li>
                      <li class="scroll-to-section"><a href="dashboard.php" class="active">Dashboard</a></li>
                      <li class="scroll-to-section">
                        <div class="main-menu">
                        <ul class="menu-list"><div class="border-first-button">
                          <li><a href="../logout.php"> Logout</a></li>
                        </ul>
                        </div>
                </div>
                <!-- ***** Menu End ***** -->
                </nav>
              </div>
             </div>
            </div>
</div>
           </header>
<br><br><br><br><br><br>
  <div style="background-image: radial-gradient( circle farthest-corner at 92.3% 71.5%,  rgba(83,138,214,1) 0%, rgba(134,231,214,1) 90% ); height: 80px;font-family: Copperplate, Papyrus, fantasy;">
    <p style="font-size: 34px; color: white; text-align: center; line-height: 75px;"><b>Dashboard</p>
  </div>

  <br>
  <br>

    <div class="container">
    <?php if(isset($_SESSION['jobPostSuccess'])) { ?>
      <div class="row successMessage" style="text-align: center; color: red; font-size: 28px;">
        <div class="alert alert-success" style="text-align: center; color: red; font-size: 28px;">
          Job Post Created Successfully!
        </div>
      </div>
    <?php unset($_SESSION['jobPostSuccess']); } ?>

    <?php if(isset($_SESSION['jobPostUpdateSuccess'])) { ?>
      <div class="row successMessage" style="text-align: center; color: red; font-size: 28px;">
        <div class="alert alert-success" style="text-align: center; color: red; font-size: 28px;">
          Job Post Updated Successfully!
        </div>
      </div>
    <?php unset($_SESSION['jobPostUpdateSuccess']); } ?>

    <?php if(isset($_SESSION['jobPostDeleteSuccess'])) { ?>
      <div class="row successMessage" style="text-align: center; color: red; font-size: 28px;">
        <div class="alert alert-success" style="text-align: center; color: red; font-size: 28px;">
          Job Post Deleted Successfully!
        </div>
      </div>
    <?php unset($_SESSION['jobPostDeleteSuccess']); } ?>

      <div class="row" align="center">
        <div style="background-color: #00FF00; border: 1px solid black; width: 50%; height: 80px; border-radius: 5px;">
          <a href="create-job-post.php" style="line-height: 75px; color: black; font-size: 26px;">Create Job Post</a>
        </div>
        <br><br>
        <div style="background-color: yellow; border: 1px solid black; width: 50%; height: 80px; border-radius: 5px;">
          <a href="view-job-post.php" style="line-height: 75px; color: black; font-size: 26px;">View Job Post</a>
        </div><br><br>
        <?php 
          $sql = "SELECT * FROM apply_job_post WHERE id_company='$_SESSION[id_user]' AND status='0'";
          $result = $conn->query($sql);
          if($result->num_rows > 0) {
            ?>
            <div style="background-color: aqua; border: 1px solid black; width: 50%; height: 80px; border-radius: 5px;">
              <a href="view-job-application.php" style="line-height: 75px; color: black; font-size: 26px;">View Applications <span>(<?php echo $result->num_rows; ?>)</span></a>
            </div>
            <?php 
          }
        ?>
      </div>
    </div>
   </div>

<?php
  include('../footer.php');
  ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <script type="text/javascript">
      $(function(){
        $(".successMessage:visible").fadeOut(5000);
      });
    </script>
  </body>
</html>