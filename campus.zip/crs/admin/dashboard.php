<?php
session_start();
if(empty($_SESSION['id_admin'])) {
  header("Location: index.php");
  exit();
}
require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Dashboard</title>

    <link rel="stylesheet" href="../assets/css/templatemo-digimedia-v1.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

  </head>
  <body>

    <font face="calibri">
    <!-- NAVIGATION BAR -->    
    <section>
      <div class="container" style="font-family: Copperplate, Papyrus, fantasy;">
        <div class="row">
        <!-- ***** Header Area Start ***** -->
          <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
            <div class="container">
              <div class="row">
                <div class="col-12">
                  <nav class="main-nav">
                  <!-- ***** Logo Start ***** -->
                    <a href="../homepage_1.php" class="logo">
                      <img src="../assets/images/C1.jpg" alt=" LOGO">
                    </a>
                  <!-- ***** Logo End ***** -->

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
          <ul class="nav navbar-nav navbar-right">
            <li style="padding-right: 25px;"><a href="../logout.php" style="font-size: 24px; color: #053a5a; line-height: 42px;">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  </div>
  </div>
  </section>
  <br><br><br><br><br><br>
  <div style="background-image: radial-gradient( circle farthest-corner at 92.3% 71.5%,  rgba(83,138,214,1) 0%, rgba(134,231,214,1) 90% ); height: 80px;font-family: Copperplate, Papyrus, fantasy;">
    <p style="font-size: 34px; color: white; text-align: center; line-height: 75px;"> Admin Dashboard</p>
    </div>
  <br>

    <div class="container">
      <div class="row">
        <div class="col-md-12" align="center" style="font-family: Copperplate, Papyrus, fantasy;">
          <div class="list-group" align="center" style="width: 50%; border: 1px solid #053a5a; border-radius: 5px;">
            <a href="dashboard.php" class="list-group-item active" style="font-size: 20px;"><b>Dashboard</a>
            <a href="user.php" class="list-group-item" style="font-size: 20px;"><b>Users</a>
            <a href="company.php" class="list-group-item" style="font-size: 20px;"><b>Company</a>
            <a href="job-posts.php" class="list-group-item" style="font-size: 20px;"><b>Job Posts</a>
          </div>
        </div>
        <div class="col-md-12" align="center">
          <h3 style="font-size: 30px;">Welcome To Dashboard, Admin!</h3>
        </div>
      </div>
    </div>
    <br><Br>
    <?php
  include('../footer.php');
  ?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </font>
  </body>
</html>