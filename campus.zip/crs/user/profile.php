<?php
  session_start();
  if(empty($_SESSION['id_user'])) {
    header("Location: ../index.php");
    exit();
}
require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>User Profile</title>

    <link rel="icon" href="../img/favicon.png" type="image/x-icon"/>

    <!-- Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <?php
include('userheader.php');
?>
<br>
<br>
  <br>
  <br>
<br>
  <br>
  <div style="background-image: radial-gradient( circle farthest-corner at 92.3% 71.5%,  rgba(83,138,214,1) 0%, rgba(134,231,214,1) 90% ); color: white; border-color: transparent; border-radius: 5px; height: 80px;font-family: Copperplate, Papyrus, fantasy;">
    <p style="font-size: 34px; color: white; text-align: center; line-height: 75px;">View / Update Profile</p>
   
  </div>

      <div class="container" style="text-shadow: 3px 3px 3px #ababab;">
        
        <div class="row">

            <form method="post" action="updateprofile.php">
                        <div class="col-md-6">
              <?php 
                $sql = "SELECT * FROM users WHERE id_user='$_SESSION[id_user]'";
                $result = $conn->query($sql);
                if($result->num_rows > 0) {
                  while($row = $result->fetch_assoc()) {
               ?>
              <div class="form-group"> <br><br>
                <label for="fname" style="font-size: 20px; color: #053a5a;">First Name :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black;" type="text" class="form-control" id="fname" name="fname" placeholder="First Name" value="<?php echo $row['firstname']; ?>" required="">
              </div>
              <div class="form-group">
                <label for="lname" style="font-size: 20px; color: #053a5a;">Last Name :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="lname" name="lname" placeholder="Last Name" value="<?php echo $row['lastname']; ?>" required="">
              </div>
              <div class="form-group">
                <label for="email" style="font-size: 20px; color: #053a5a;">Email Address :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="email" class="form-control" id="email"  placeholder="Email" value="<?php echo $row['email']; ?>" readonly>
              </div>
              <div class="form-group">
                <label for="address" style="font-size: 20px; color: #053a5a;">Address :</label>
                <textarea style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; color: black; " id="address" name="address" class="form-control" rows="4" placeholder="Address"><?php echo $row['address']; ?></textarea>
              </div>
              <div class="form-group">
                <label for="city" style="font-size: 20px; color: #053a5a;">City :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="city" name="city" placeholder="City" value="<?php echo $row['city']; ?>">
              </div>
              <div class="form-group">
                <label for="state" style="font-size: 20px; color: #053a5a;">State :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="state" name="state" placeholder="State" value="<?php echo $row['state']; ?>">
              </div>
                  </div>
          <div class="col-md-6">
              <div class="form-group"> <br><br>
                <label for="contactno" style="font-size: 20px; color: #053a5a;">Contact Number :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="number" class="form-control" id="contactno" minlength="10" maxlength="10" name="contactno" placeholder="Contact Number" value="<?php echo $row['contactno']; ?>">
              </div>

             <!-- <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="qualification">Highest Qualification :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="qualification" name="qualification" placeholder="Qualification" value="<?php echo $row['qualification']; ?>">
              </div>-->
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="stream">Stream :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="stream" name="stream" placeholder="Stream" value="<?php echo $row['stream']; ?>" readonly>
              </div>
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="ssc">SSC Marks:</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="ssc" name="ssc" placeholder="10th percentage" value="<?php echo $row['ssc']; ?>" >
              </div>
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="hsc">HSC Marks:</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="hsc" name="hsc" placeholder="12th percentage" value="<?php echo $row['hsc']; ?>" >
              </div>
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="passingyear">Passing Year :</label>
                <input type="number" placeholder="YYYY" min="2022" max="2023" style="border:1px solid black; border-radius: 5px; width: 80%; height: 45px; padding: 15px; font-size: 18px;font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="date" class="form-control" id="passingyear" name="passingyear" placeholder="Passing Year" value="<?php echo $row['passingyear']; ?>">
              </div>
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="dob">Date of Birth :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="date" class="form-control" id="dob" name="dob" placeholder="Date of Birth" value="<?php echo $row['dob']; ?>">
              </div>
              <div class="form-group" style="font-size: 20px; color: #053a5a;">
                <label for="age">Age :</label>
                <input style="font-size: 20px; padding-left: 15px; padding-right: 15px; border: 1px solid black; border-radius: 5px; width: 100%; height: 40px; color: black; " type="text" class="form-control" id="age" name="age" placeholder="Age" value="<?php echo $row['age']; ?>">
           </div>
            <div class="col-md-12">
              <br>
            </div>
            <div class="col-md-12">
              <div class="text-center">
                <button class="btn-hover color-7 " type="submit" style="font-size: 18px; background-image: linear-gradient( 135deg, #3B2667 10%, #BC78EC 100%); color: white; width: 20%; height: 50px; border-color: transparent; border-radius: 5px;">Update</button>
              </div>
            </div>
              <?php 
                }
              }
            ?>

            </form>
          </div>
        </div>
      </div>

      <br>

    <!-- Navigation Bar End -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

  </body>
  
  <?php
  include('footer.php');
  ?>

</html>