<?php
session_start();
if(empty($_SESSION['id_user'])) {
  header("Location: ../index.php");
  exit();
}
require_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Dashboard</title>


    <link rel="stylesheet" href="../stylesheet.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    
<?php
include('userheader.php');
?>
 <br>
  <br>
  <br>
  <br>
  <br>
  <br>

     
  <div style="background-image: linear-gradient( 109.6deg,  rgba(62,161,219,1) 11.2%, rgba(93,52,236,1) 100.2% ); height: 80px;">
    <h1 style="font-size: 34px; color: white; text-align: center; line-height: 75px;font-family: Copperplate, Papyrus, fantasy;"><b>My Dashboard</b></h1>
  </div>

  <br>
  <br>

    <div class="container">

      <?php if(isset($_SESSION['jobApplySuccess'])) { ?> 
      <div><br>
                <h1 id="successMessage" style="text-align: center; color: red; font-size: 28px;font-family: Copperplate, Papyrus, fantasy;">You have applied successfully!</h1>
              </div>
      <?php unset($_SESSION['jobApplySuccess']); } ?>


      <!-- Other dashboard functions -->
      <div align="center"><br><br>
          <a href="applied-jobs.php" style="background-color: #053a5a;font-family: Copperplate, Papyrus, fantasy; border-color: transparent; border-radius: 5px; padding-left: 25px; padding-right: 25px; padding-top: 10px; padding-bottom: 13px; color: white; font-size: 18px; text-decoration: none;">Your Applied Drives</a>
          <a href="resume.php" style="background-color: #053a5a; font-family: Copperplate, Papyrus, fantasy;border-color: transparent; border-radius: 5px; padding-left: 25px; padding-right: 25px; padding-top: 10px; padding-bottom: 13px; color: white; font-size: 18px; text-decoration: none;">Upload/Download Resume</a>
      </div>
      <Br>
      <hr style="border-color:#053a5a;">
      <div style="height: 80px;">
    <h1 style="font-size: 38px; color: black; text-align: center; line-height: 75px;font-family: Copperplate, Papyrus, fantasy;"><b>Active Jobs</b></h1>
  </div>



      <!-- Search & Apply to Job Posts -->
      <div class="row">

            <table border="2px solid #053a5a" class="table-striped" width="100%">
              <thead >
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 15%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Job Name</th>
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 15%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Job Description</th>
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 15%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Minimum Salary</th>
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 15%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Maximum Salary</th>
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 10%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Stream</th>
                <th style="padding-left: 15px; padding-right: 15px; font-size: 22px; width: 15%; padding-top: 10px; padding-bottom: 10px; color: #053a5a;font-family: Copperplate, Papyrus, fantasy;"><b>Action</th>
              </thead>
              <tbody>
                <?php 
                  $sql = "SELECT * FROM job_post";
                  $result = $conn->query($sql);
                  if($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) 
                    {
                      $sql1 = "SELECT * FROM apply_job_post WHERE id_user='$_SESSION[id_user]' AND id_jobpost='$row[id_jobpost]'";
                      $result1 = $conn->query($sql1);
                      
                     ?>
                      <tr>
                        <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;"><?php echo $row['jobtitle']; ?></td>
                        <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;"><?php echo $row['description']; ?></td>
                        <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;">Rs.<?php echo $row['minimumsalary']; ?></td>
                        <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;">Rs.<?php echo $row['maximumsalary']; ?></td>
                    <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 10%; padding-top: 10px; padding-bottom: 10px;"><?php echo $row['stream']; ?></td>
  
                        <?php
                        if($result1->num_rows > 0) {
                          ?>
                            <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;font-family: Copperplate, Papyrus, fantasy;"><strong>Applied!</strong></td>
                          <?php
                        } else {
                       ?>
                       <td style="padding-left: 15px; padding-right: 15px; font-size: 20px; width: 15%; padding-top: 10px; padding-bottom: 10px;font-family: Copperplate, Papyrus, fantasy;"><a href="apply-job-post.php?id=<?php echo $row['id_jobpost']; ?>">Apply</a></td>
                       <?php } ?>
                      </tr>
                     <?php
                    }
                  }
                  $conn->close();
                ?>
              </tbody>
            </table>
          </div>
        </div>
          <br><br>

<?php
  include('../footer.php');
  ?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <script type="text/javascript">
      $(function(){
        $(".successMessage:visible").fadeOut(5000);
      });
    </script>

  </body>
</html>