<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">



    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../assets/css/fontawesome.css">
    <link rel="stylesheet" href="stylesheet.css">


  </head>
  <footer>
    <div class="container" >
      <div class="row">
        <div class="col-lg-12">
          <p>Copyright &copy; 2022 | All rights Reserved | <a href="homepage_1.php" style="color:white;">Campus Placement</a> <br>
          <a href="https://www.facebook.com/TataConsultancyServices" target="_blank"><img src="facebook.png" style="width: 30px; height: 30px; margin-left: 5px; margin-right: 5px; align:center;" /></a>
      <a href="https://www.twitter.com/tcs" target="_blank"><img src="twitter.png" style="width: 30px; height: 30px; margin-left: 5px; margin-right: 5px;" /></a>
      <a href="https://www.youtube.com/channel/UCaHyiyvJp4hhPNhIU7r9uqg" target="_blank"><img src="youtube.png" style="width: 30px; height: 30px; margin-left: 5px; margin-right: 5px;" /></a>
    
         
      </div>
        </div>
      </div>
    </div>
  </footer>